# Controle de Mídia — Luiz & Kaly

App novo pra substituir o placeholder que estava no repositório `CONTROLE-SERIES`.

## O que tem de novo
- **Status de cada série**: clique na badge azul/cinza/amarela no card pra mudar entre
  Assistindo, Finalizado, Aguardando nova temporada, Pausado.
- **Aviso automático de novidade**: um botão "Checar novos episódios/temporadas" consulta
  a API oficial e gratuita do TMDB (themoviedb.org) e mostra "NOVO EP" ou "NOVA TEMPORADA"
  em cima do card quando sair algo novo.
- Os dados ficam salvos no navegador (localStorage) — não tem mais backend/nuvem por enquanto.

## Como colocar no seu repositório (pelo Codespace)

1. Abra o terminal do Codespace do projeto `CONTROLE-SERIES`.
2. Apague o conteúdo antigo da pasta `app` e adicione as pastas novas:
   ```bash
   rm -rf app components
   ```
3. Copie/cole (ou envie via upload no VS Code) as pastas `app`, `components`, `lib` e os
   arquivos da raiz (`package.json`, `tailwind.config.ts`, `postcss.config.mjs`,
   `next.config.mjs`, `tsconfig.json`) deste zip para dentro do repositório.
4. Instale as dependências e rode local pra conferir:
   ```bash
   npm install
   npm run dev
   ```
5. Suba pro GitHub:
   ```bash
   git add .
   git commit -m "Novo app com status e integracao TMDB"
   git push
   ```
   A Vercel vai fazer o deploy automático assim que detectar o push.

## Como pegar a chave gratuita do TMDB
1. Crie uma conta em https://www.themoviedb.org
2. Vá em Configurações (Settings) → API
3. Solicite uma "API Key (v3 auth)" — é gratuito e aprovação é quase instantânea
4. Cole a chave dentro do próprio app, na seção "Chave da API do TMDB"

## Próximos passos possíveis (se quiser evoluir)
- Trocar localStorage por um banco de dados real (Supabase é gratuito e fácil de integrar
  com Next.js) pra sincronizar entre o seu celular e o da Kaly.
- Rodar a checagem de novidades automaticamente todo dia (ex: um Cron Job na Vercel),
  em vez de precisar clicar no botão.
