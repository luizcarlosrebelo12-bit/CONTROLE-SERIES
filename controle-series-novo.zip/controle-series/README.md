# Controle de Mídia — Luiz & Kaly

App novo pra substituir o placeholder que estava no repositório `CONTROLE-SERIES`.

## O que tem de novo
- **Ícones de verdade** (biblioteca lucide-react) em vez de emojis — evita aquele visual
  quebrado/linha fina que aparece dependendo do sistema operacional.
- **Status de cada série**: clique na badge azul/cinza/amarela no card pra mudar entre
  Assistindo, Finalizado, Aguardando nova temporada, Pausado.
- **Editar mídia já cadastrada**: clique no lápis no card, o formulário abre preenchido
  no topo com "Editando: NOME".
- **Aviso automático de novidade**: um botão "Checar novos episódios/temporadas" consulta
  a API oficial e gratuita do TMDB (themoviedb.org) e mostra "NOVO EP" ou "NOVA TEMPORADA"
  em cima do card quando sair algo novo.
- **Salvo na nuvem de verdade** via Supabase (banco de dados gratuito), pra você e a Kaly
  verem a mesma lista em qualquer aparelho. Se o Supabase não estiver configurado, o app
  continua funcionando salvando só no navegador (modo local).

## Como configurar o Supabase (nuvem) — uns 5 minutos

1. Crie uma conta gratuita em https://supabase.com e clique em **"New project"**.
2. Dê um nome (ex: `controle-series`) e uma senha de banco (guarde ela, mas não vai
   precisar usar no dia a dia).
3. Espere o projeto terminar de ser criado (1-2 minutos).
4. No menu lateral, vá em **SQL Editor** → **New query**, cole o conteúdo do arquivo
   `supabase_schema.sql` (está junto deste zip) e clique em **Run**. Isso cria a tabela
   `midias` onde as séries/filmes vão ficar salvos.
5. Vá em **Project Settings** (ícone de engrenagem) → **API**. Copie:
   - **Project URL**
   - **anon public key**
6. No seu projeto (Codespace ou localmente), crie um arquivo chamado `.env.local` na raiz
   com este conteúdo (substituindo pelos seus valores):
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://seu-projeto.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=sua-chave-anon-aqui
   ```
7. Na **Vercel**, vá no seu projeto → **Settings** → **Environment Variables**, e adicione
   as duas mesmas variáveis (`NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY`)
   com os mesmos valores. Isso é necessário porque o `.env.local` não vai para o GitHub
   (por segurança) — é preciso configurar direto na Vercel também.
8. Depois de adicionar as variáveis na Vercel, force um novo deploy (Deployments → nos
   três pontinhos do último deployment → **Redeploy**).

⚠️ Nota de segurança: como não tem login/senha no app, qualquer pessoa que tiver a URL e
a chave do Supabase consegue ler/escrever nos dados. Pra um app pessoal entre vocês dois
isso é geralmente aceitável, mas não compartilhe essas credenciais publicamente (nunca
suba o arquivo `.env.local` para o GitHub).

## Como colocar no seu repositório (pelo Codespace)

1. Abra o terminal do Codespace do projeto `CONTROLE-SERIES`.
2. Apague o conteúdo antigo da pasta `app` e adicione as pastas novas:
   ```bash
   rm -rf app components
   ```
3. Copie/cole (ou envie via upload no VS Code) as pastas `app`, `components`, `lib` e os
   arquivos da raiz (`package.json`, `tailwind.config.ts`, `postcss.config.mjs`,
   `next.config.mjs`, `tsconfig.json`) deste zip para dentro do repositório.
4. Instale as dependências e rode local pra conferir:
   ```bash
   npm install
   npm run dev
   ```
5. Suba pro GitHub:
   ```bash
   git add .
   git commit -m "Novo app com status e integracao TMDB"
   git push
   ```
   A Vercel vai fazer o deploy automático assim que detectar o push.

## Como pegar a chave gratuita do TMDB
1. Crie uma conta em https://www.themoviedb.org
2. Vá em Configurações (Settings) → API
3. Solicite uma "API Key (v3 auth)" — é gratuito e aprovação é quase instantânea
4. Cole a chave dentro do próprio app, na seção "Chave da API do TMDB"

## Próximos passos possíveis (se quiser evoluir)
- Trocar localStorage por um banco de dados real (Supabase é gratuito e fácil de integrar
  com Next.js) pra sincronizar entre o seu celular e o da Kaly.
- Rodar a checagem de novidades automaticamente todo dia (ex: um Cron Job na Vercel),
  em vez de precisar clicar no botão.
